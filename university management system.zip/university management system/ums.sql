-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2020 at 09:01 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ums`
--

-- --------------------------------------------------------

--
-- Table structure for table `budget`
--

CREATE TABLE `budget` (
  `budgetId` int(11) NOT NULL,
  `universityId` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `budgetYear` int(11) NOT NULL,
  `budgetType` varchar(64) NOT NULL,
  `expend` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `departmentId` int(11) NOT NULL,
  `facultyId` int(11) DEFAULT NULL,
  `departmentName` varchar(64) NOT NULL,
  `departmentHead` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`departmentId`, `facultyId`, `departmentName`, `departmentHead`) VALUES
(1, 1, 'labriatoor', 'Ahmad'),
(3, 1, 'IS', 'ahmad'),
(7, 1, 'IT', 'ahmad'),
(8, 1, 'IT', 'ahmad');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employeeId` int(11) NOT NULL,
  `firstName` varchar(32) NOT NULL,
  `lastName` varchar(32) NOT NULL,
  `fatherName` varchar(32) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `nic` tinyint(4) NOT NULL,
  `phone` char(10) NOT NULL,
  `email` varchar(129) DEFAULT NULL,
  `photos` blob NOT NULL,
  `provinceId` int(11) NOT NULL,
  `district` varchar(64) NOT NULL,
  `localtion` varchar(64) NOT NULL,
  `education` varchar(32) NOT NULL,
  `rigstertionDate` date NOT NULL,
  `poistion` varchar(32) NOT NULL,
  `grossSalary` int(11) NOT NULL,
  `universityId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `employeeexperience`
--

CREATE TABLE `employeeexperience` (
  `experienceId` int(11) NOT NULL,
  `employeeId` int(11) NOT NULL,
  `orgFrom` varchar(32) NOT NULL,
  `orgTo` varchar(32) NOT NULL,
  `promote` varchar(255) NOT NULL,
  `benefit` varchar(255) NOT NULL,
  `surcharge` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `facultyId` int(11) NOT NULL,
  `universityId` int(11) NOT NULL,
  `facultyName` varchar(64) NOT NULL,
  `managerName` varchar(64) NOT NULL,
  `viceManager` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`facultyId`, `universityId`, `facultyName`, `managerName`, `viceManager`) VALUES
(1, 3, 'Madical Faculty', 'Ahmad ali', 'babi'),
(8, 3, 'df', 'fd', 'sf');

-- --------------------------------------------------------

--
-- Table structure for table `province`
--

CREATE TABLE `province` (
  `provinceId` int(11) NOT NULL,
  `provinceName` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `province`
--

INSERT INTO `province` (`provinceId`, `provinceName`) VALUES
(7, 'Azad Kashmir'),
(2, 'Balochistan'),
(8, 'Gilgat'),
(4, 'KPK'),
(9, 'Ningrahar'),
(6, 'Paswaon'),
(3, 'Punjab'),
(1, 'Sindh');

-- --------------------------------------------------------

--
-- Table structure for table `ranking`
--

CREATE TABLE `ranking` (
  `rankId` int(11) NOT NULL,
  `universityId` int(11) NOT NULL,
  `rankYear` int(11) NOT NULL,
  `rankPoint` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ranking`
--

INSERT INTO `ranking` (`rankId`, `universityId`, `rankYear`, `rankPoint`) VALUES
(18, 3, 2018, 1);

-- --------------------------------------------------------

--
-- Table structure for table `scholarship`
--

CREATE TABLE `scholarship` (
  `scholarId` int(11) NOT NULL,
  `personId` int(11) NOT NULL,
  `scholarshipDate` date NOT NULL,
  `universityId` int(11) NOT NULL,
  `country` varchar(64) NOT NULL,
  `universityName` varchar(64) NOT NULL,
  `personType` varchar(64) NOT NULL,
  `requirement` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `score`
--

CREATE TABLE `score` (
  `studentId` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL,
  `semester` tinyint(4) NOT NULL,
  `percentage` tinyint(4) NOT NULL,
  `mark` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentId` int(11) NOT NULL,
  `firstName` varchar(64) NOT NULL,
  `lastName` varchar(64) NOT NULL,
  `fatherName` varchar(64) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `nic` int(11) NOT NULL,
  `phone` char(10) NOT NULL,
  `email` varchar(64) DEFAULT NULL,
  `provinceId` int(11) DEFAULT NULL,
  `district` varchar(64) NOT NULL,
  `localtion` varchar(64) NOT NULL,
  `photo` blob DEFAULT NULL,
  `registrationDate` date NOT NULL,
  `kankorMark` int(11) NOT NULL,
  `registrationYear` int(11) NOT NULL,
  `graduationYear` int(11) DEFAULT NULL,
  `monographTitile` varchar(255) DEFAULT NULL,
  `departmentId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentId`, `firstName`, `lastName`, `fatherName`, `gender`, `nic`, `phone`, `email`, `provinceId`, `district`, `localtion`, `photo`, `registrationDate`, `kankorMark`, `registrationYear`, `graduationYear`, `monographTitile`, `departmentId`) VALUES
(1, 'AHmad ', 'moahmmadi', 'abdullah', 0, 2211, '0771010100', NULL, 2, '', '', NULL, '2018-03-22', 320, 2018, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `studentdocument`
--

CREATE TABLE `studentdocument` (
  `documentStudentId` int(11) NOT NULL,
  `studentId` int(11) NOT NULL,
  `documentTitle` text NOT NULL,
  `documentFile` blob NOT NULL,
  `fileType` varchar(64) NOT NULL,
  `attachDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subjectId` int(11) NOT NULL,
  `subjectName` varchar(64) NOT NULL,
  `universityId` int(11) DEFAULT NULL,
  `facultyId` int(11) DEFAULT NULL,
  `departmentId` int(11) DEFAULT NULL,
  `credit` tinyint(4) NOT NULL,
  `subjectType` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacherId` int(11) NOT NULL,
  `universityId` int(11) NOT NULL,
  `facultyId` int(11) NOT NULL,
  `departmentId` int(11) NOT NULL,
  `firstName` varchar(64) NOT NULL,
  `lastName` varchar(64) NOT NULL,
  `fatherName` varchar(64) NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `nic` varchar(14) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `email` varchar(120) DEFAULT NULL,
  `provinceId` int(11) NOT NULL,
  `district` varchar(32) NOT NULL,
  `location` varchar(32) NOT NULL,
  `registrationDate` date NOT NULL,
  `photos` blob DEFAULT NULL,
  `education` varchar(64) NOT NULL,
  `academicRank` tinyint(4) NOT NULL,
  `contractType` tinyint(1) NOT NULL,
  `salaryRemark` varchar(255) NOT NULL,
  `payableSalary` int(11) NOT NULL,
  `birthYear` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacherId`, `universityId`, `facultyId`, `departmentId`, `firstName`, `lastName`, `fatherName`, `gender`, `nic`, `phone`, `email`, `provinceId`, `district`, `location`, `registrationDate`, `photos`, `education`, `academicRank`, `contractType`, `salaryRemark`, `payableSalary`, `birthYear`) VALUES
(1, 3, 1, 1, 'Ahmadullah', 'Moahmmadi', 'Nabi', 1, '1231', '0799120100', '', 7, 'sdfj', 'asdj', '2018-03-07', 0x89504e470d0a1a0a0000000d4948445200000018000000180806000000e0773df8000000017352474200aece1ce9000000097048597300000b1300000b1301009a9c18000001cb69545874584d4c3a636f6d2e61646f62652e786d7000000000003c783a786d706d65746120786d6c6e733a783d2261646f62653a6e733a6d6574612f2220783a786d70746b3d22584d5020436f726520352e342e30223e0a2020203c7264663a52444620786d6c6e733a7264663d22687474703a2f2f7777772e77332e6f72672f313939392f30322f32322d7264662d73796e7461782d6e7323223e0a2020202020203c7264663a4465736372697074696f6e207264663a61626f75743d22220a202020202020202020202020786d6c6e733a786d703d22687474703a2f2f6e732e61646f62652e636f6d2f7861702f312e302f220a202020202020202020202020786d6c6e733a746966663d22687474703a2f2f6e732e61646f62652e636f6d2f746966662f312e302f223e0a2020202020202020203c786d703a43726561746f72546f6f6c3e41646f626520496d61676552656164793c2f786d703a43726561746f72546f6f6c3e0a2020202020202020203c746966663a4f7269656e746174696f6e3e313c2f746966663a4f7269656e746174696f6e3e0a2020202020203c2f7264663a4465736372697074696f6e3e0a2020203c2f7264663a5244463e0a3c2f783a786d706d6574613e0a292ecd3d0000040049444154480db555cb6e5c45103dddb7efccf8e2d7642606432222821550d8401445bc2221041220a42c82814d765921be012ff90256b0c90629e61fbc22120b245844a004e444023b8e3d0f7b3caffbaa9cbaf78ec9d8131022b434d33dd5dda74e9daaea01fee761145f5656ac5959491bcb579721f29940da06d603d287dc5baef9db70f6f889e3b13d035143d508bea97ef7f5b511a6cb4eddbc9939422a2f1d9b99bd381cf4e014e8f0b03c16274048aca929fa2b08d01c715da90468763a3ff2da351498b98302c818f4c2411fdd38eed1e41fe02b631d8308980e606a73908d2d9ee011917c8f3eeca01f884dbb6a582dace334a98b6f2d4848c17d5ef661ad8ffd7eb696df377def83777cf7f9555f86914f99f2fde2bcdeb5e978e8e30e88aa7c0e38592be80d04674e09a62a629f7f5adc9baf8a3b735adce5f7057fec081ccf300a923ab85690cfa63189d4c283f9a05e99c66184e8caa730eb775021905d580012e2befb36d2b51b90dd0e105468636e268c89112819f11d41ef21bdfc1e92932720e7cfc17beb62563d320c61179f84f7c925e0d606e0587087c647c5efdcc1ea6a169e1685d1a43982b7f7202f2f2156506e9467a66183806a709f5ab3e2e05ebb00f3e11b90cdc641c28bba6296734ccb0beeceda5a491d4ac979a297158415132f5f427afc383479a57239e7e4912d3f922630f333701f330a95931289569bef72d2b76ffb8aed8c31da2059d7b8ad46d73cb39837d14215deafb760d7efc223405c7239fb519694843aa35ce6a91ad01fc0562cfce69e9638ccd2d25067b7b9b973de435adf9e9b6ff4bef8f26cf0d32fb41a23691fe6abebb0fb21840ea26e0ce3b15ff5562623cbb94d8c1aa379f124edc686bb5dec9f7dee859faff72e2c76f7aba9f5da6663abb11d0441bdb5d7c170730ba5765b84ccd8f2d49aa16bf813070bc1302ab0f62502c5801d8448e6aac62dd6313d55461845b13ad875cecd26712ca9b5463c2705cf89b023a3027b8cd2932ea2e409d84e1fc3630186d1ae9935f359a496b9d33e88b5324838354962ed23ea79049ccfcabe043f6ca29cdc45d23f85d26f7fa2f7ca09b4c2759909ce5155c3e24b6136ee379bcef3aa711c6b853d428f4966d5b0b08fb669d2654637679245902ff3280af3e149c1268dc28926fd00da6469e377e6287b2a5422cf7370ecde4cbc11a34998476c85f311072d69fe5724945a9db80c9cff2dad760bdb3b0d16cebf423fe22e25d97aad86d9d9992c0774c0f7951dd86cb5f1fd8d1f4ca954fa4bc311ab2330130ce4a58c87c3215ee713323f3f974562ee6db7eef3789ddb2155e3db9bab3901e21f4d0fdf55653419aedbebd7ebb5ba09c3b0ac913c8e9181135fabc935da7bdfb6da9d67a9dd802fa9d55afdaf6ed804da075a40adc741f86f311e006dafc09693106e830000000049454e44ae426082, '2015', 1, 1, 'sddafsdfasdfsadfasdfsadf', 17900, '0');

-- --------------------------------------------------------

--
-- Table structure for table `teacherattendance`
--

CREATE TABLE `teacherattendance` (
  `teacherId` int(11) NOT NULL,
  `attendaceYear` int(11) NOT NULL,
  `attendanceMonth` tinyint(4) NOT NULL,
  `semester` tinyint(4) NOT NULL,
  `absentCredit` tinyint(4) NOT NULL DEFAULT 0,
  `presentCredit` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teacherattendance`
--

INSERT INTO `teacherattendance` (`teacherId`, `attendaceYear`, `attendanceMonth`, `semester`, `absentCredit`, `presentCredit`) VALUES
(1, 1990, 12, 2, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `teacherdocument`
--

CREATE TABLE `teacherdocument` (
  `documentTeacherId` int(11) NOT NULL,
  `teacherId` int(11) NOT NULL,
  `documentTitle` text NOT NULL,
  `file` blob DEFAULT NULL,
  `fileType` varchar(64) NOT NULL,
  `attachDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teacherdocument`
--

INSERT INTO `teacherdocument` (`documentTeacherId`, `teacherId`, `documentTitle`, `file`, `fileType`, `attachDate`) VALUES
(2, 1, 'sksclkfsda;lf', NULL, 'png', '2018-01-01'),
(4, 1, 'zcxczxc', 0x89504e470d0a1a0a0000000d4948445200000018000000180806000000e0773df8000000017352474200aece1ce90000000467414d410000b18f0bfc6105000000097048597300000ec300000ec301c76fa8640000011a49444154484b6360200c78804aca80f80c107f07e29f407c09881b805888b076fc2a7480d2f780f83f0efc1c286e45ae2552408d2f900c06b9fc28101f02e2af48e21f816c0d722c598a64c86e201b64210c8082663592fc5e522d10066af80d35001444dc580c60018a9d45b2448d144b3c9034d6e2d19886a42e81140b229134c6e3d1e88ea4ae905c0be2f0687443b2a0885c0bf0f9806c0b2481ae01c503084be3719908923a05527c4013b54a40531f52099b6373a13a5284e12a1a8815b71f9416fc05ba6a3310af05e25f047c4b960ff290bc1d460b0b900b3b503904f211ae3821cb0711483e70a4850fbe010d15076236207e4f0b0b40c101caad1c442467b282086401a85cf2a5a505433ba311eb7a903a781c0000dcd11669300dee170000000049454e44ae426082, 'zcxc', '2018-04-02'),
(5, 1, 'this is some text', 0x303030314243373046443430443530313937454544460d0a353830353038413136434230453931303230314143410d0a0d0a4461746120537472756374757265090d0a37384536414141443235363037423737363436393430364332353730354442353230303131463439324637304131393641440d0a0d0a4a6176612050726f6a65637420090d0a32344346464645363742314546333638464546424244463736443031344237303045384231423041414342453944424338300d0a0d0a46616365626f6f6b2050726f6a656374200d0a3634333938384545433132464143363937433541374238334635303741303838373533434144343241414239453341353737, 'txt', '2018-04-02');

-- --------------------------------------------------------

--
-- Table structure for table `teachersalary`
--

CREATE TABLE `teachersalary` (
  `teacherId` int(11) NOT NULL DEFAULT 0,
  `salaryYear` int(11) NOT NULL DEFAULT 0,
  `salaryMonth` tinyint(4) NOT NULL DEFAULT 0,
  `semester` tinyint(4) NOT NULL,
  `paymentDate` date NOT NULL,
  `absentAmount` int(11) NOT NULL DEFAULT 0,
  `taxAmount` int(11) NOT NULL DEFAULT 0,
  `retireAmount` int(11) NOT NULL DEFAULT 0,
  `netSalary` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teachersalary`
--

INSERT INTO `teachersalary` (`teacherId`, `salaryYear`, `salaryMonth`, `semester`, `paymentDate`, `absentAmount`, `taxAmount`, `retireAmount`, `netSalary`) VALUES
(1, 2018, 1, 3, '2018-03-07', 0, 500, 900, 17900);

-- --------------------------------------------------------

--
-- Table structure for table `university`
--

CREATE TABLE `university` (
  `universityId` int(11) NOT NULL,
  `unName` varchar(64) NOT NULL,
  `unType` tinyint(1) NOT NULL,
  `manager` varchar(32) NOT NULL,
  `provinceId` int(11) NOT NULL,
  `district` varchar(64) NOT NULL,
  `localtion` varchar(128) NOT NULL,
  `establishDate` date NOT NULL,
  `organizationStructure` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `university`
--

INSERT INTO `university` (`universityId`, `unName`, `unType`, `manager`, `provinceId`, `district`, `localtion`, `establishDate`, `organizationStructure`) VALUES
(3, 'UOL', 1, 'Ahmad', 3, 'Lahore', 'Lahore', '2019-01-01', 'this is good university			'),
(13, 'Umt', 0, 'umer', 3, 'Nak', 'df', '2020-12-11', 'dca');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(64) NOT NULL,
  `userType` tinyint(1) NOT NULL DEFAULT 0,
  `adminLevel` tinyint(4) NOT NULL DEFAULT 0,
  `hrLevel` tinyint(4) NOT NULL DEFAULT 0,
  `financeLevel` tinyint(4) NOT NULL DEFAULT 0,
  `academicLevel` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `username`, `password`, `userType`, `adminLevel`, `hrLevel`, `financeLevel`, `academicLevel`) VALUES
(1, 'admin', '123', 8, 8, 8, 8, 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `budget`
--
ALTER TABLE `budget`
  ADD PRIMARY KEY (`budgetId`),
  ADD KEY `UN_BU_FK` (`universityId`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`departmentId`),
  ADD KEY `UN_DR_FK` (`facultyId`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employeeId`),
  ADD UNIQUE KEY `nic` (`nic`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `UN_PR_EM_FK` (`provinceId`),
  ADD KEY `UN_EM_FK` (`universityId`);

--
-- Indexes for table `employeeexperience`
--
ALTER TABLE `employeeexperience`
  ADD PRIMARY KEY (`experienceId`),
  ADD KEY `EM_EMXP_FK` (`employeeId`);

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`facultyId`),
  ADD KEY `UN_FU_FK` (`universityId`);

--
-- Indexes for table `province`
--
ALTER TABLE `province`
  ADD PRIMARY KEY (`provinceId`),
  ADD UNIQUE KEY `provinceName` (`provinceName`);

--
-- Indexes for table `ranking`
--
ALTER TABLE `ranking`
  ADD PRIMARY KEY (`rankId`),
  ADD KEY `UN_RAN_FK` (`universityId`);

--
-- Indexes for table `scholarship`
--
ALTER TABLE `scholarship`
  ADD PRIMARY KEY (`scholarId`),
  ADD KEY `UN_SC_FK` (`universityId`);

--
-- Indexes for table `score`
--
ALTER TABLE `score`
  ADD PRIMARY KEY (`studentId`,`subjectId`),
  ADD KEY `SU_SB_FK` (`subjectId`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentId`),
  ADD KEY `DE_ST_FK` (`departmentId`),
  ADD KEY `PR_ST_FK` (`provinceId`);

--
-- Indexes for table `studentdocument`
--
ALTER TABLE `studentdocument`
  ADD PRIMARY KEY (`documentStudentId`),
  ADD KEY `ST_STDU_FK` (`studentId`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subjectId`),
  ADD KEY `SU_UN_FK` (`universityId`),
  ADD KEY `FU_SB_FK` (`facultyId`),
  ADD KEY `DE_SB_FK` (`departmentId`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacherId`),
  ADD KEY `UN_TE_FK` (`universityId`),
  ADD KEY `FU_TE_FK` (`facultyId`),
  ADD KEY `FU_DE_FK` (`departmentId`),
  ADD KEY `TE_PR_FK` (`provinceId`);

--
-- Indexes for table `teacherattendance`
--
ALTER TABLE `teacherattendance`
  ADD PRIMARY KEY (`teacherId`,`attendaceYear`,`attendanceMonth`);

--
-- Indexes for table `teacherdocument`
--
ALTER TABLE `teacherdocument`
  ADD PRIMARY KEY (`documentTeacherId`),
  ADD KEY `FU_TEDE_FK` (`teacherId`);

--
-- Indexes for table `teachersalary`
--
ALTER TABLE `teachersalary`
  ADD PRIMARY KEY (`teacherId`,`salaryYear`,`salaryMonth`);

--
-- Indexes for table `university`
--
ALTER TABLE `university`
  ADD PRIMARY KEY (`universityId`),
  ADD UNIQUE KEY `unName` (`unName`),
  ADD KEY `UN_PR_FK` (`provinceId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `budget`
--
ALTER TABLE `budget`
  MODIFY `budgetId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `departmentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `employeeId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employeeexperience`
--
ALTER TABLE `employeeexperience`
  MODIFY `experienceId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `facultyId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `province`
--
ALTER TABLE `province`
  MODIFY `provinceId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ranking`
--
ALTER TABLE `ranking`
  MODIFY `rankId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `scholarship`
--
ALTER TABLE `scholarship`
  MODIFY `scholarId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `studentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `studentdocument`
--
ALTER TABLE `studentdocument`
  MODIFY `documentStudentId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subjectId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teacher`
--
ALTER TABLE `teacher`
  MODIFY `teacherId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `teacherdocument`
--
ALTER TABLE `teacherdocument`
  MODIFY `documentTeacherId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `university`
--
ALTER TABLE `university`
  MODIFY `universityId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `budget`
--
ALTER TABLE `budget`
  ADD CONSTRAINT `UN_BU_FK` FOREIGN KEY (`universityId`) REFERENCES `university` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `department`
--
ALTER TABLE `department`
  ADD CONSTRAINT `UN_DR_FK` FOREIGN KEY (`facultyId`) REFERENCES `faculty` (`facultyId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `UN_EM_FK` FOREIGN KEY (`universityId`) REFERENCES `university` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `UN_PR_EM_FK` FOREIGN KEY (`provinceId`) REFERENCES `province` (`provinceId`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `employeeexperience`
--
ALTER TABLE `employeeexperience`
  ADD CONSTRAINT `EM_EMXP_FK` FOREIGN KEY (`employeeId`) REFERENCES `employee` (`employeeId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `faculty`
--
ALTER TABLE `faculty`
  ADD CONSTRAINT `UN_FU_FK` FOREIGN KEY (`universityId`) REFERENCES `university` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ranking`
--
ALTER TABLE `ranking`
  ADD CONSTRAINT `UN_RAN_FK` FOREIGN KEY (`universityId`) REFERENCES `university` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `scholarship`
--
ALTER TABLE `scholarship`
  ADD CONSTRAINT `UN_SC_FK` FOREIGN KEY (`universityId`) REFERENCES `university` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `score`
--
ALTER TABLE `score`
  ADD CONSTRAINT `SC_ST_FK` FOREIGN KEY (`studentId`) REFERENCES `student` (`studentId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `SU_SB_FK` FOREIGN KEY (`subjectId`) REFERENCES `subject` (`subjectId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `DE_ST_FK` FOREIGN KEY (`departmentId`) REFERENCES `department` (`departmentId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `PR_ST_FK` FOREIGN KEY (`provinceId`) REFERENCES `province` (`provinceId`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `studentdocument`
--
ALTER TABLE `studentdocument`
  ADD CONSTRAINT `ST_STDU_FK` FOREIGN KEY (`studentId`) REFERENCES `student` (`studentId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `subject`
--
ALTER TABLE `subject`
  ADD CONSTRAINT `DE_SB_FK` FOREIGN KEY (`departmentId`) REFERENCES `department` (`departmentId`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FU_SB_FK` FOREIGN KEY (`facultyId`) REFERENCES `faculty` (`facultyId`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `SU_UN_FK` FOREIGN KEY (`universityId`) REFERENCES `university` (`universityId`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `teacher`
--
ALTER TABLE `teacher`
  ADD CONSTRAINT `FU_DE_FK` FOREIGN KEY (`departmentId`) REFERENCES `department` (`departmentId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FU_TE_FK` FOREIGN KEY (`facultyId`) REFERENCES `faculty` (`facultyId`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `TE_PR_FK` FOREIGN KEY (`provinceId`) REFERENCES `province` (`provinceId`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `UN_TE_FK` FOREIGN KEY (`universityId`) REFERENCES `university` (`universityId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teacherattendance`
--
ALTER TABLE `teacherattendance`
  ADD CONSTRAINT `TE_ATT_FK` FOREIGN KEY (`teacherId`) REFERENCES `teacher` (`teacherId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teacherdocument`
--
ALTER TABLE `teacherdocument`
  ADD CONSTRAINT `FU_TEDE_FK` FOREIGN KEY (`teacherId`) REFERENCES `teacher` (`teacherId`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teachersalary`
--
ALTER TABLE `teachersalary`
  ADD CONSTRAINT `FU_TESA_FK` FOREIGN KEY (`teacherId`) REFERENCES `teacher` (`teacherId`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Constraints for table `university`
--
ALTER TABLE `university`
  ADD CONSTRAINT `UN_PR_FK` FOREIGN KEY (`provinceId`) REFERENCES `province` (`provinceId`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
