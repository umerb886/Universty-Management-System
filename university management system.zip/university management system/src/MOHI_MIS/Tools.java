/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MOHI_MIS;

import java.awt.Toolkit;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JFrame;


public class Tools {

    public void setCenter(JFrame frame){
        
        double screenWidth  = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
        double screenHeight = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
        
        int frameWidth = frame.getWidth();
        int frameHeight = frame.getHeight();
        
        double x = (screenWidth - frameWidth) / 2;
        double y = (screenHeight - frameHeight) / 2;
        
        frame.setLocation((int)x,(int)y);
        
    }
    
    public void setSetting(JFrame frame){
        
        
        frame.setTitle("University Management System");   
       
    }    
    
    
}
