/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MOHI_MIS;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;    
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class JConnection {
    
    public Connection con;
    public Statement st;
    public ResultSet rs;
    
    public void connect(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/ums","root","");
            st =  (Statement) con.createStatement();
        }
        catch(Exception e){
            new JConnection().erroreMessage(null, e);
        }
    }   
    
    public void erroreMessage(JFrame frame , Exception e){
          JOptionPane.showMessageDialog(frame,"erroe" + e.getMessage());
    }
   
    
    public String[][] showAllList(String query){
        try{
            connect();
            rs = st.executeQuery(query);
            rs.last();
            int rows = rs.getRow();
            int col = rs.getMetaData().getColumnCount();
            rs.beforeFirst();
            
           String[][] data = new String[rows][col];
            int x = 0;
            while(rs.next()){
                for(int y = 0; y<col;y++){
                    data[x][y] = rs.getString(y+1);
                }
                x++;
            }
            return data;
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"erroe" + e.getMessage());
            return null;
        }
    }
    
    
    
    public String[] ids;
    public String[] Names;
    public String[] boundComboBox(JComboBox combo,String tableName,String culmnId,String culmnName){
        try{
            connect();
            rs = st.executeQuery("SELECT * FROM "+tableName+"");
            rs.last();
            int totalrow = rs.getRow();
            
           ids = new String[totalrow+1];
           Names = new String[totalrow+1];
         
           Names[0] = "Choose ithem";
            rs.beforeFirst();
            
            int r = 1;
            while(rs.next()){
                ids[r] = rs.getString(culmnId);
                Names[r] = rs.getString(culmnName);
                r++;
            }
            DefaultComboBoxModel model = new DefaultComboBoxModel(Names);
            combo.setModel(model);
            return ids;
        
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
              return null;
        }
        
    } 
    
    public String[] idss;
    public String[] boundComboBox(JComboBox combo,String tableName,String condation,String culmnId,String culmnName){
        try{
            connect();
            rs = st.executeQuery("SELECT * FROM "+tableName+" WHERE "+condation+"");
            rs.last();
            int totalrow = rs.getRow();
            
           idss = new String[totalrow+1];
           String[] Names = new String[totalrow+1];
            Names[0] = "Choose ithem";
            rs.beforeFirst();
            
            int r = 1;
            while(rs.next()){
                idss[r] = rs.getString(culmnId);
                Names[r] = rs.getString(culmnName);
                r++;
            }
            DefaultComboBoxModel model = new DefaultComboBoxModel(Names);
            combo.setModel(model);
            return idss;
        
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
              return null;
        }
        
    }

    public String[] idsss;
    public String[] Namess;
    public String[] boundComboBoxs(JComboBox combo,String tableName,String culmnId,String culmnName){
        try{
            connect();
            rs = st.executeQuery("SELECT * FROM "+tableName+"");
            rs.last();
            int totalrow = rs.getRow();
            
           idsss = new String[totalrow];
           Namess = new String[totalrow];
         rs.beforeFirst();
            int r = 1;
            while(rs.next()){
                idsss[r] = rs.getString(culmnId);
                Namess[r] = rs.getString(culmnName);
                r++;
            }
            DefaultComboBoxModel model = new DefaultComboBoxModel(Namess);
            combo.setModel(model);
            return idsss;
        
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
              return null;
        }
        
    } 
    
    

}